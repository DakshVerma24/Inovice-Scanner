# Invoice QR Scanner

Flask backend + browser frontend that scans uploaded invoice PDFs for QR codes,
decodes them (base64/JWT-style or plain JSON), and lets you view raw/decoded
text or download everything as an Excel workbook — all without leaving the page.

## Local run

```bash
pip install -r requirements.txt
# pyzbar needs the system zbar library:
#   Debian/Ubuntu: sudo apt-get install libzbar0
#   macOS:         brew install zbar
python app.py
```

Visit http://localhost:5000

## Project structure

```
app.py              Flask backend (QR detection/decoding + API routes)
templates/index.html Frontend page
static/style.css    Frontend styling
static/index.js      Frontend logic (upload, drag/drop, results, download)
requirements.txt    Python deps
Procfile             Render/gunicorn start command
render.yaml           Render blueprint (installs libzbar0, then pip installs)
```

## API

- `POST /api/scan` — form-data field `files` (one or more PDFs) → JSON with
  per-file raw text, decoded fields, and a summary (counts + elapsed time).
- `POST /api/scan/excel` — same input → streams back `invoice_data.xlsx`
  directly (a "Failed" sheet is added if any files couldn't be read).
- `GET /api/health` — simple health check.

## Deploying on Render

1. Push this folder to a GitHub repo.
2. In Render, "New +" → "Blueprint", point it at the repo — `render.yaml`
   handles the build command (`apt-get install libzbar0` + `pip install`)
   and the start command automatically.
   - Alternatively, create a plain "Web Service" and manually set:
     - Build Command: `apt-get update && apt-get install -y libzbar0 && pip install -r requirements.txt`
     - Start Command: `gunicorn app:app --bind 0.0.0.0:$PORT --timeout 120`
3. Once deployed, the frontend at `/` calls the API on the same origin
   automatically (`API_BASE = window.location.origin` in `static/index.js`).
   If you ever split frontend and backend across different hosts, just hardcode
   `API_BASE` to the backend's URL — CORS is already enabled in `app.py`.

## Notes

- Max upload size is capped at 50 MB total per request (`MAX_CONTENT_LENGTH`
  in `app.py`) — raise it if you expect bigger batches.
- QR detection tries multiple render scales (1.5x–4x) and image variants
  (raw, thresholded, sharpened) with both OpenCV and pyzbar decoders, falling
  through until one succeeds — mirrors the original script's approach but
  reads PDFs from memory instead of disk.
- Files that fail (no QR found, corrupt PDF, etc.) don't stop the batch —
  they're reported individually and land on the "Failed" sheet in Excel.
